# Portfolio Personal - Proyecto de FrontEnd del segundo cuatrimestre de 2024

## Descripción
Como parte de la cursada de la materia FrontEnd, comencé a realizar una página web. El proyecto consta de los siguientes archivos:

- `index.html`: La página principal con la estructura del portfolio.
- `styles.css`: Archivo externo de estilos CSS que define la apariencia del sitio.

## Mejoras Futuras
- Agregar más secciones sobre proyectos y experiencias.
- Implementar funcionalidad en el formulario para enviar los datos a una base.
- Mejorar el diseño.
